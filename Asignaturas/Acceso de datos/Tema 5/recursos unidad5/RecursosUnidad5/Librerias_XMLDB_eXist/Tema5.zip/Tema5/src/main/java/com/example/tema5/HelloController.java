package com.example.tema5;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.xmldb.api.base.Resource;
import org.xmldb.api.base.ResourceIterator;
import org.xmldb.api.base.ResourceSet;
import org.xmldb.api.base.XMLDBException;
import org.xmldb.api.modules.XPathQueryService;

public class HelloController {
    @FXML
    private TextField Departamento;
    @FXML
    private TextField Nombre;
    @FXML
    private TextField Localidad;

    public void Limpiar(ActionEvent actionEvent) {
        Departamento.setText("");
        Nombre.setText("");
        Localidad.setText("");
    }

    public void Modificacion(ActionEvent actionEvent) {
        XPathQueryService service;
        try {
            service = (XPathQueryService) globals.col.getService("XPathQueryService", "1.0");
            String nombre = "/departamentos/DEP_ROW[DEPT_NO=" + Departamento.getText() + "]/DNOMBRE/text()";
            ResourceSet resultNombre1 = service.query(nombre);
            if(resultNombre1.getSize() == 0){
                Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Departamento no existe", ButtonType.OK);
                a.showAndWait();
                return;
            }
            String query = "update replace /departamentos/DEP_ROW[DEPT_NO = " + Departamento.getText() + "] with "
                    + "<DEP_ROW> <DEPT_NO>" + Departamento.getText() + "</DEPT_NO> <DNOMBRE>" + Nombre.getText() + "</DNOMBRE> <LOC>" + Localidad.getText() + "</LOC></DEP_ROW>";
            ResourceSet result = service.query(query);
            if (result != null) {
                Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Departamento modificado", ButtonType.OK);
                a.showAndWait();
            }
        } catch (XMLDBException e) {
            throw new RuntimeException(e);
        }
    }

    public void Baja(ActionEvent actionEvent) {
        XPathQueryService service;
        try {
            service = (XPathQueryService) globals.col.getService("XPathQueryService", "1.0");
            String nombre = "/departamentos/DEP_ROW[DEPT_NO=" + Departamento.getText() + "]/DNOMBRE/text()";
            ResourceSet resultNombre = service.query(nombre);
            if(resultNombre.getSize() == 0){
                Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Departamento no existe", ButtonType.OK);
                a.showAndWait();
                return;
            }
            String query = "update delete /departamentos/DEP_ROW[DEPT_NO = " + Departamento.getText() + "]";
            ResourceSet result = service.query(query);
            if (result != null) {
                Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Departamento dado de baja", ButtonType.OK);
                a.showAndWait();
            }
        } catch (XMLDBException e) {
            throw new RuntimeException(e);
        }
    }

    public void Alta(ActionEvent actionEvent) {
        XPathQueryService service;
        try {
            service = (XPathQueryService) globals.col.getService("XPathQueryService", "1.0");
            String nombre = "/departamentos/DEP_ROW[DEPT_NO=" + Departamento.getText() + "]/DNOMBRE/text()";
            ResourceSet resultNombre = service.query(nombre);
            if(resultNombre.getSize() != 0){
                Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Departamento ya existe", ButtonType.OK);
                a.showAndWait();
                return;
            }
            String query = "update insert <DEP_ROW> <DEPT_NO>" + Departamento.getText() + "</DEPT_NO> <DNOMBRE>" + Nombre.getText() + "</DNOMBRE> <LOC>" + Localidad.getText() + "</LOC></DEP_ROW> into /departamentos";
            ResourceSet result = service.query(query);
            if (result != null) {
                Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Departamento Insertado", ButtonType.OK);
                a.showAndWait();
            }
        } catch (XMLDBException e) {
            throw new RuntimeException(e);
        }
    }

    public void Consultar(ActionEvent actionEvent) {
        XPathQueryService service;
        try {
            service = (XPathQueryService) globals.col.getService("XPathQueryService", "1.0");
            String nombre = "/departamentos/DEP_ROW[DEPT_NO=" + Departamento.getText() + "]/DNOMBRE/text()";
            ResourceSet resultNombre1 = service.query(nombre);
            if(resultNombre1.getSize() == 0){
                Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Departamento no existe", ButtonType.OK);
                a.showAndWait();
                return;
            }
            String query = "/departamentos/DEP_ROW[DEPT_NO=" + Departamento.getText() + "]/DNOMBRE/text()";
            String query2 = "/departamentos/DEP_ROW[DEPT_NO=" + Departamento.getText() + "]/LOC/text()";
            ResourceSet resultNombre = service.query(query);
            ResourceSet resultLoc = service.query(query2);
            System.out.println(resultNombre.getSize());
            System.out.println(resultLoc.getSize());
            ResourceIterator i = resultNombre.getIterator();
            ResourceIterator j = resultLoc.getIterator();
            if (!i.hasMoreResources() && !j.hasMoreResources()) {
                System.out.println("Consulta nulla");
            } else {
                while (i.hasMoreResources() && j.hasMoreResources()) {
                    Resource r = i.nextResource();
                    Resource rs = j.nextResource();
                    Nombre.setText((String) r.getContent());
                    Localidad.setText((String) rs.getContent());
                    System.out.println((String) r.getContent());
                    System.out.println((String) rs.getContent());
                }
            }
        } catch (XMLDBException e) {
            throw new RuntimeException(e);
        }
    }
}