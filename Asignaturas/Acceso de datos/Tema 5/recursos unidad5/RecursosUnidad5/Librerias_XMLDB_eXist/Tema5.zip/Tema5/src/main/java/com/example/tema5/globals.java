package com.example.tema5;

import org.xmldb.api.base.Collection;
import org.xmldb.api.modules.XMLResource;

public class globals {
    public static XMLResource res;
    public static Collection col;
}
