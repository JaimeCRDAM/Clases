package com.example.tema5;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;
import org.xmldb.api.*;




import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) throws XMLDBException {
        String driver = "org.exist.xmldb.DatabaseImpl";
        try {
            Class cl = Class.forName(driver);
            Database database = (Database) cl.newInstance();
            DatabaseManager.registerDatabase(database);
        } catch (ClassNotFoundException e) {
            System.out.println("Clase no encontrada: " + driver);
        } catch (InstantiationException e) {
            System.out.println("No se puede instanciar: " + driver);
        } catch (IllegalAccessException e) {
            System.out.println("No se puede acceder: " + driver);
        } catch (XMLDBException e) {
            System.out.println("Error: " + e.getMessage());
        }
        String URI="xmldb:exist://localhost:8080/exist/xmlrpc/db/Pruebas";
        String usu = "admin";
        String usuPwd = "";
        Collection col = DatabaseManager.getCollection(URI, usu, usuPwd);
        globals.col = col;
        launch();

    }

}