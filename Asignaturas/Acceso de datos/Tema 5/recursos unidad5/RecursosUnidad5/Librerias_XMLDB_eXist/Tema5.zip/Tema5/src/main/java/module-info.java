module com.example.tema5 {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires xmldb;

    opens com.example.tema5 to javafx.fxml;
    exports com.example.tema5;
}