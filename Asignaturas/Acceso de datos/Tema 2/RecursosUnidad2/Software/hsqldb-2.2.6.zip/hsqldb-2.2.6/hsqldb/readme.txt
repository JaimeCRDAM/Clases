Readme File
$Date: 2011-11-20 09:04:10 -0500 (Sun, 20 Nov 2011) $
This package contains HyperSQL v. 2.2.6

HyperSQL is a relational database engine and a set of tools written in Java.
HyperSQL is also known as HSQLDB.

The file "index.html" explains the contents of this distribution and has
links to documentation and support resources.
